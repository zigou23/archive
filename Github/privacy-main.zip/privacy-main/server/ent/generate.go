package ent

//go:generate go run github.com/facebook/ent/cmd/entc generate ./schema
